Data comes from the following demonstration house:

http://www.nrel.gov/docs/fy08osti/43188.pdf
http://www.nrel.gov/docs/fy08osti/42591.pdf